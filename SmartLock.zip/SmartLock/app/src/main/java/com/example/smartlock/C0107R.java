package com.example.smartlock;

public final class C0107R {

    public static final class attr {
    }

    public static final class color {
        public static final int bg_color = 2131034112;
        public static final int contents_text = 2131034113;
        public static final int encode_view = 2131034114;
        public static final int grgray = 2131034138;
        public static final int header = 2131034137;
        public static final int help_button_view = 2131034115;
        public static final int help_view = 2131034116;
        public static final int my = 2131034139;
        public static final int possible_result_points = 2131034117;
        public static final int result_image_border = 2131034118;
        public static final int result_minor_text = 2131034119;
        public static final int result_points = 2131034120;
        public static final int result_text = 2131034121;
        public static final int result_view = 2131034122;
        public static final int sbc_header_text = 2131034123;
        public static final int sbc_header_view = 2131034124;
        public static final int sbc_layout_view = 2131034126;
        public static final int sbc_list_item = 2131034125;
        public static final int sbc_page_number_text = 2131034127;
        public static final int sbc_snippet_text = 2131034128;
        public static final int share_text = 2131034129;
        public static final int share_view = 2131034130;
        public static final int status_text = 2131034132;
        public static final int status_view = 2131034131;
        public static final int transparent = 2131034133;
        public static final int viewfinder_frame = 2131034134;
        public static final int viewfinder_laser = 2131034135;
        public static final int viewfinder_mask = 2131034136;
    }

    public static final class dimen {
        public static final int activity_horizontal_margin = 2131099648;
        public static final int activity_vertical_margin = 2131099649;
    }

    public static final class drawable {
        public static final int bg = 2130837504;
        public static final int dl = 2130837505;
        public static final int ic_launcher = 2130837506;
        public static final int ks = 2130837507;
        public static final int navbar = 2130837508;
        public static final int sm = 2130837509;
    }

    public static final class id {
        public static final int action_settings1 = 2131165201;
        public static final int action_settings2 = 2131165202;
        public static final int auto_focus = 2131165184;
        public static final int button1 = 2131165197;
        public static final int button2 = 2131165198;
        public static final int button3 = 2131165199;
        public static final int button4 = 2131165200;
        public static final int decode = 2131165185;
        public static final int decode_failed = 2131165186;
        public static final int decode_succeeded = 2131165187;
        public static final int encode_failed = 2131165188;
        public static final int encode_succeeded = 2131165189;
        public static final int launch_product_query = 2131165190;
        public static final int quit = 2131165191;
        public static final int restart_preview = 2131165192;
        public static final int return_scan_result = 2131165193;
        public static final int search_book_contents_failed = 2131165194;
        public static final int search_book_contents_succeeded = 2131165195;
        public static final int textView = 2131165196;
    }

    public static final class layout {
        public static final int activity_main = 2130903040;
    }

    public static final class menu {
        public static final int main = 2131361792;
    }

    public static final class raw {
        public static final int beep = 2130968576;
        public static final int realm_properties = 2130968577;
    }

    public static final class string {
        public static final int action_settings1 = 2131230722;
        public static final int action_settings2 = 2131230723;
        public static final int app_name = 2131230720;
        public static final int hello_world = 2131230721;
    }

    public static final class style {
        public static final int AppBaseTheme = 2131296256;
        public static final int AppTheme = 2131296257;
    }
}
